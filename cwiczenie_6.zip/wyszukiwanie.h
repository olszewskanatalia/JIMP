/* plik naglowkowy wyszukiwania */


#ifndef _WYSZUKIWANIE_H_
#define _WYSZUKIWANIE_H_

void dodaj (int **skoro, int index_slowa, int nr_linii);

void wyszukaj(FILE *plik, int ile_slow, int **skorowidz, char **slowa);

#endif
