/* plik naglowkowy wypisanie skorowidza */

#ifndef _SKOROWIDZ_H_
#define _SKOROWIDZ_H_

void wypisz_skorowidz(int **, char **, int );

#endif

